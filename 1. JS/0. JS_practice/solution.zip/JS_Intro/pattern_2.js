function processData(input) {
    //Enter your code here
    
                let n=input;
                let i=0;
                let space=1;
                let star=Math.floor(n/2)+1;
                while(i<n){
    
                    for(let j=0;j<star;j++){
                   process.stdout.write("*");
               }   
                    for(let j=0;j<space;j++){
                        process.stdout.write(" ");
                    }
                    for(let j=0;j<star;j++){
                        process.stdout.write("*");
                    }
                    console.log();
                   let num= Math.floor(n/2);
           if(i<num){
               star-=1;
               space+=2;
               
           }else{
            star+=1;
               space-=2;
           }
                    i++;
                }

} 

process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});

process.stdin.on("end", function () {
   processData(_input);
});
