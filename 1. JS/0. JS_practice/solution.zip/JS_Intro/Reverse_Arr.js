function processData(input) {
    //Enter your code here
    // console.log(arr);
    
    let arr=JSON.parse(input);
    let length=arr.length;
    let nArr=[];
    for(let i=0;i<length;i++){
            nArr.push(arr.pop())        
    }
    console.log(nArr);
} 
process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});
process.stdin.on("end", function () {
   processData(_input);
});