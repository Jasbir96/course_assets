function processData(input) {
    //Enter your code here
    let dec=input
    let pow=1;
    let bin=0;
    while(dec!=0){
        let fv=dec%2;    
        bin=bin+fv*pow;
        dec=Math.floor(dec/2);
        pow=pow*10;
    }
    console.log(bin)
} 
process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});
process.stdin.on("end", function () {
   processData(_input);
});
