function processData(input) {
    //Enter your code here
    let inputArr =input.split("\n");
    let size= Number.parseInt((inputArr[0]));
    let arr= inputArr.slice(1,size);
    let data =inputArr[inputArr.length-1];
    // console.log(size);
    // console.log(array);
    // console.log(element);
    let left = 0;
    let right = arr.length - 1;
    let fi = -1;
    while(left <= right){
       let mid = Math.floor((left + right) / 2);
       if(data > arr[mid]){
         left = mid + 1;
       } else if(data < arr[mid]){
         right = mid - 1;
       } else  {
          fi = mid;
          right = mid - 1;
       }
    }
    left = 0;
    right = arr.length - 1;
    let li = -1;
    while(left <= right){
       let mid = Math.floor((left + right) / 2);
       if(data > arr[mid]){
         left = mid + 1;
       } else if(data < arr[mid]){
         right = mid - 1;
       } else  {
          li = mid;
          left = mid + 1;
       }
    }
   console.log(fi); 
    console.log(li);
} 
process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});
process.stdin.on("end", function () {
   processData(_input);
});