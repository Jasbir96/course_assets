function processData(input) {
    //Enter your code here
   let stringArr= input.split(" ");
    for(let i=0;i<stringArr.length;i++){
        let word=stringArr[i];
        let newWord=word.charAt(0).toUpperCase()+word.slice(1);
        stringArr[i]=newWord;
    }
   let titleCase= stringArr.join(" ");
console.log(titleCase);
} 
process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});
process.stdin.on("end", function () {
   processData(_input);
});