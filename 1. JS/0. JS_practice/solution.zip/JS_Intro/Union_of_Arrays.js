function processData(input) {
    // Enter your code here
// separating string
    let ans= input.split("\n");
    let first=JSON.parse(ans[0]);
    let second=JSON.parse(ans[1]);
    for(let i=0;i<second.length;i++){
        if(first.includes(second[i])==false){
            first.push(second[i]);
        }
    }
    console.log(first)
} 
process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});
process.stdin.on("end", function () {
   processData(_input);
});