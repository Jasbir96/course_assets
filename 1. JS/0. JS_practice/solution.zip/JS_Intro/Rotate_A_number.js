function processData(input) {
    //Enter your code here
    // strings array and split
    let arr=input.split("\n");
    let count=arr[0];
    let number=arr[1];
     let  nod = 0;
    let n=number;
    let k= count;
    let  temp = number;
    while (temp != 0) {
      temp = Math.floor(temp/10);
      nod++;
    }

    k = k % nod;
    if (k < 0)
      k += nod;

    let div = 1;
    let mult = 1;
    for (let i = 1; i <= nod; i++) {
      if (i <= k)
        div *= 10;
      else
        mult *= 10;
    }

    let quo = Math.floor(n / div);
    let rem = n % div;

    let r = rem * mult + quo;
    console.log(r);
} 

process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});

process.stdin.on("end", function () {
   processData(_input);
});
