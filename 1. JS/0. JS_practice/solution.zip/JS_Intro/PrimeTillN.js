function processData(input) {
    //Enter your code here
    for(let numberToCheck=2;numberToCheck<=input;numberToCheck++){
        let flag=true
        for(let div=2;div*div<=numberToCheck;div++){
            if(numberToCheck%div==0){
                     flag=false;
                break;
            }
        }
        if(flag==true){
            process.stdout.write(numberToCheck+" ");
        }
    } 
} 