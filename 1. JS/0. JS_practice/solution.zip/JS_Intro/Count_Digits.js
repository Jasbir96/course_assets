function processData(input) {
    //Enter your code here
    let length=0;
    let count=0
    while(input>0){
        input=Math.floor(input/10);
        count++;
    }
    console.log(count);
} 

process.stdin.resume();
process.stdin.setEncoding("ascii");
_input = "";
process.stdin.on("data", function (input) {
    _input += input;
});

process.stdin.on("end", function () {
   processData(_input);
});
