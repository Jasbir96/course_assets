// Setup
var contacts = [
    {
        "firstName": "Akira",
        "lastName": "Laine",
        "number": "0543236543",
        "likes": ["Pizza", "Coding", "Brownie Points"]
    },
    {
        "firstName": "Harry",
        "lastName": "Potter",
        "number": "0994372684",
        "likes": ["Hogwarts", "Magic", "Hagrid"]
    },
    {
        "firstName": "Sherlock",
        "lastName": "Holmes",
        "number": "0487345643",
        "likes": ["Intriguing Cases", "Violin"]
    },
    {
        "firstName": "Kristian",
        "lastName": "Vos",
        "number": "unknown",
        "likes": ["JavaScript", "Gaming", "Foxes"]
    }
];
function lookUpProfile(name, prop) {
    for (let i = 0; i < contacts.length; i++) {
        let contact = contacts[i];
        if (contact["firstName"] == name) {
            if (contact[prop] == undefined) {
                console.log("No such property");
            } else {
                console.log(contact[prop]);

            }
            return;
        }
    }
    console.log("No such contact");
}
lookUpProfile("Kristian", "lastName")
lookUpProfile("Sherlock", "likes")
lookUpProfile("Harry", "likes")
lookUpProfile("Bob", "number")
lookUpProfile("Bob", "potato")
lookUpProfile("Akira", "address")